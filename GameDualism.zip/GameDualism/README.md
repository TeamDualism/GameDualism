﻿# DualismGame

Чтобы запустить данный проект необходимо скачать и установить Android Studio(v 2.2.3) (https://developer.android.com/studio/index.html).
Стандартная установка.
После установки выбрать "Открыть проект" и указать build.gradle.

[Grotto Escape II - Environment](http://opengameart.org/content/grotto-escape-ii-environment) created by [Luis Zuno](http://ansimuz.com) is licensed under CC-BY-3.0  
Character artwork credit wil be added later
